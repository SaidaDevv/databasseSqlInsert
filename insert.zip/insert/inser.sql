---1
INSERT INTO public.film(
      title, description, release_year, language_id, original_language_id, rental_duration, rental_rate, length, replacement_cost, rating, last_update, special_features, fulltext)
VALUES 
    ( 'Me before you', 'Film description', 2018, 1, NULL, 7, 4.99, 120, 19.99, 'PG', '2019-10-22 10:00:00', '{Trailers}', 
    to_tsvector('russian', 'Me before you film description'));


---2

INSERT INTO public.actor( first_name, last_name)
	VALUES  ('Sam', 'Claflin'),
       ('Emilia', 'Clarke'),
       ('Jenna','Coleman');


--3
INSERT INTO film_category (film_id, category_id)

VALUES (1, 3);

       